# Vietnam license-plate > 2023-02-13 9:39pm
https://universe.roboflow.com/tran-ngoc-xuan-tin-k15-hcm-dpuid/vietnam-license-plate-h8t3n

Provided by a Roboflow user
License: CC BY 4.0

